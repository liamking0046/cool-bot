module.exports = {
    name: "index",
    description: "Sample command for index",
    execute(client, message, args) {
        message.reply("index command executed!");
    }
};