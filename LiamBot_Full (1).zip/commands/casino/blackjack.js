module.exports = {
    name: "blackjack",
    description: "Sample command for blackjack",
    execute(client, message, args) {
        message.reply("blackjack command executed!");
    }
};