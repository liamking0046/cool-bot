module.exports = {
    name: "slot",
    description: "Sample command for slot",
    execute(client, message, args) {
        message.reply("slot command executed!");
    }
};