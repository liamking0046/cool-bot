module.exports = {
    name: "coinflip",
    description: "Sample command for coinflip",
    execute(client, message, args) {
        message.reply("coinflip command executed!");
    }
};