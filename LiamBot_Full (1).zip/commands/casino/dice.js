module.exports = {
    name: "dice",
    description: "Sample command for dice",
    execute(client, message, args) {
        message.reply("dice command executed!");
    }
};