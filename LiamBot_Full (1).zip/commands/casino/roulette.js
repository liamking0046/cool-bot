module.exports = {
    name: "roulette",
    description: "Sample command for roulette",
    execute(client, message, args) {
        message.reply("roulette command executed!");
    }
};