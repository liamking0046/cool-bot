module.exports = {
    name: "meme15",
    description: "Sample command for meme15",
    execute(client, message, args) {
        message.reply("meme15 command executed!");
    }
};