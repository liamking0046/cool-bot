module.exports = {
    name: "meme3",
    description: "Sample command for meme3",
    execute(client, message, args) {
        message.reply("meme3 command executed!");
    }
};