module.exports = {
    name: "meme6",
    description: "Sample command for meme6",
    execute(client, message, args) {
        message.reply("meme6 command executed!");
    }
};