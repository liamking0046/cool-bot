module.exports = {
    name: "meme10",
    description: "Sample command for meme10",
    execute(client, message, args) {
        message.reply("meme10 command executed!");
    }
};