module.exports = {
    name: "meme13",
    description: "Sample command for meme13",
    execute(client, message, args) {
        message.reply("meme13 command executed!");
    }
};