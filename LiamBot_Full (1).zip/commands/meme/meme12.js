module.exports = {
    name: "meme12",
    description: "Sample command for meme12",
    execute(client, message, args) {
        message.reply("meme12 command executed!");
    }
};