module.exports = {
    name: "meme11",
    description: "Sample command for meme11",
    execute(client, message, args) {
        message.reply("meme11 command executed!");
    }
};