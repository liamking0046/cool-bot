module.exports = {
    name: "meme2",
    description: "Sample command for meme2",
    execute(client, message, args) {
        message.reply("meme2 command executed!");
    }
};