module.exports = {
    name: "meme9",
    description: "Sample command for meme9",
    execute(client, message, args) {
        message.reply("meme9 command executed!");
    }
};