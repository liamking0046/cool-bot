module.exports = {
    name: "meme5",
    description: "Sample command for meme5",
    execute(client, message, args) {
        message.reply("meme5 command executed!");
    }
};