module.exports = {
    name: "meme14",
    description: "Sample command for meme14",
    execute(client, message, args) {
        message.reply("meme14 command executed!");
    }
};