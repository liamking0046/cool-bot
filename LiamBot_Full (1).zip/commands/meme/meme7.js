module.exports = {
    name: "meme7",
    description: "Sample command for meme7",
    execute(client, message, args) {
        message.reply("meme7 command executed!");
    }
};