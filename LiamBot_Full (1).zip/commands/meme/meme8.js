module.exports = {
    name: "meme8",
    description: "Sample command for meme8",
    execute(client, message, args) {
        message.reply("meme8 command executed!");
    }
};