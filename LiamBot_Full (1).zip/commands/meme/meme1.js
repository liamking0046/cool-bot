module.exports = {
    name: "meme1",
    description: "Sample command for meme1",
    execute(client, message, args) {
        message.reply("meme1 command executed!");
    }
};