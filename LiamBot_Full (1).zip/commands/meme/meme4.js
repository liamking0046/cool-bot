module.exports = {
    name: "meme4",
    description: "Sample command for meme4",
    execute(client, message, args) {
        message.reply("meme4 command executed!");
    }
};