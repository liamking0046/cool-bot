module.exports = {
    name: "welcome",
    description: "Sample command for welcome",
    execute(client, message, args) {
        message.reply("welcome command executed!");
    }
};