module.exports = {
    name: "setrules",
    description: "Sample command for setrules",
    execute(client, message, args) {
        message.reply("setrules command executed!");
    }
};