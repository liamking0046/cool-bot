module.exports = {
    name: "antilink",
    description: "Sample command for antilink",
    execute(client, message, args) {
        message.reply("antilink command executed!");
    }
};