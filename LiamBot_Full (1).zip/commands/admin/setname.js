module.exports = {
    name: "setname",
    description: "Sample command for setname",
    execute(client, message, args) {
        message.reply("setname command executed!");
    }
};