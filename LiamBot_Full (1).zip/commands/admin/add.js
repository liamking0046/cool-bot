module.exports = {
    name: "add",
    description: "Sample command for add",
    execute(client, message, args) {
        message.reply("add command executed!");
    }
};