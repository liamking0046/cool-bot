module.exports = {
    name: "demote",
    description: "Sample command for demote",
    execute(client, message, args) {
        message.reply("demote command executed!");
    }
};