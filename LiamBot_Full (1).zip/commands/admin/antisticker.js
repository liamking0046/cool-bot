module.exports = {
    name: "antisticker",
    description: "Sample command for antisticker",
    execute(client, message, args) {
        message.reply("antisticker command executed!");
    }
};