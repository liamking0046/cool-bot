module.exports = {
    name: "unban",
    description: "Sample command for unban",
    execute(client, message, args) {
        message.reply("unban command executed!");
    }
};