module.exports = {
    name: "revoke",
    description: "Sample command for revoke",
    execute(client, message, args) {
        message.reply("revoke command executed!");
    }
};