module.exports = {
    name: "unmute",
    description: "Sample command for unmute",
    execute(client, message, args) {
        message.reply("unmute command executed!");
    }
};