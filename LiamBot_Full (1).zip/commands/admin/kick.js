module.exports = {
    name: "kick",
    description: "Sample command for kick",
    execute(client, message, args) {
        message.reply("kick command executed!");
    }
};