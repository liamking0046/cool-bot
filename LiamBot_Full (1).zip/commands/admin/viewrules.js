module.exports = {
    name: "viewrules",
    description: "Sample command for viewrules",
    execute(client, message, args) {
        message.reply("viewrules command executed!");
    }
};