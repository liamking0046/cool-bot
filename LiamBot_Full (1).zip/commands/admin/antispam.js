module.exports = {
    name: "antispam",
    description: "Sample command for antispam",
    execute(client, message, args) {
        message.reply("antispam command executed!");
    }
};