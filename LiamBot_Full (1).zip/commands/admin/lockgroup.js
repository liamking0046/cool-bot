module.exports = {
    name: "lockgroup",
    description: "Sample command for lockgroup",
    execute(client, message, args) {
        message.reply("lockgroup command executed!");
    }
};