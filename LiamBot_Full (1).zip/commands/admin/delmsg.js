module.exports = {
    name: "delmsg",
    description: "Sample command for delmsg",
    execute(client, message, args) {
        message.reply("delmsg command executed!");
    }
};