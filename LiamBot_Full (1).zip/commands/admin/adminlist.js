module.exports = {
    name: "adminlist",
    description: "Sample command for adminlist",
    execute(client, message, args) {
        message.reply("adminlist command executed!");
    }
};