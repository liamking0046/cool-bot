module.exports = {
    name: "seticon",
    description: "Sample command for seticon",
    execute(client, message, args) {
        message.reply("seticon command executed!");
    }
};