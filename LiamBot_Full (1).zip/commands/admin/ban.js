module.exports = {
    name: "ban",
    description: "Sample command for ban",
    execute(client, message, args) {
        message.reply("ban command executed!");
    }
};