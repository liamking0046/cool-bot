module.exports = {
    name: "setdesc",
    description: "Sample command for setdesc",
    execute(client, message, args) {
        message.reply("setdesc command executed!");
    }
};