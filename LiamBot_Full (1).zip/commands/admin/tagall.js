module.exports = {
    name: "tagall",
    description: "Sample command for tagall",
    execute(client, message, args) {
        message.reply("tagall command executed!");
    }
};