module.exports = {
    name: "antiNSFW",
    description: "Sample command for antiNSFW",
    execute(client, message, args) {
        message.reply("antiNSFW command executed!");
    }
};