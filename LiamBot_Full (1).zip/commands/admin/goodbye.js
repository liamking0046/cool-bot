module.exports = {
    name: "goodbye",
    description: "Sample command for goodbye",
    execute(client, message, args) {
        message.reply("goodbye command executed!");
    }
};