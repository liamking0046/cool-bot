module.exports = {
    name: "mute",
    description: "Sample command for mute",
    execute(client, message, args) {
        message.reply("mute command executed!");
    }
};