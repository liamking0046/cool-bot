module.exports = {
    name: "unlockgroup",
    description: "Sample command for unlockgroup",
    execute(client, message, args) {
        message.reply("unlockgroup command executed!");
    }
};