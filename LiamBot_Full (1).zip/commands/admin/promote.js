module.exports = {
    name: "promote",
    description: "Sample command for promote",
    execute(client, message, args) {
        message.reply("promote command executed!");
    }
};