module.exports = {
    name: "fun9",
    description: "Sample command for fun9",
    execute(client, message, args) {
        message.reply("fun9 command executed!");
    }
};