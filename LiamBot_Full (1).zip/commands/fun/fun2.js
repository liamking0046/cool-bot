module.exports = {
    name: "fun2",
    description: "Sample command for fun2",
    execute(client, message, args) {
        message.reply("fun2 command executed!");
    }
};