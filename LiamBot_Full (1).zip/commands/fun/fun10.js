module.exports = {
    name: "fun10",
    description: "Sample command for fun10",
    execute(client, message, args) {
        message.reply("fun10 command executed!");
    }
};