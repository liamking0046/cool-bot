module.exports = {
    name: "fun14",
    description: "Sample command for fun14",
    execute(client, message, args) {
        message.reply("fun14 command executed!");
    }
};