module.exports = {
    name: "fun8",
    description: "Sample command for fun8",
    execute(client, message, args) {
        message.reply("fun8 command executed!");
    }
};