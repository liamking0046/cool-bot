module.exports = {
    name: "fun15",
    description: "Sample command for fun15",
    execute(client, message, args) {
        message.reply("fun15 command executed!");
    }
};