module.exports = {
    name: "fun12",
    description: "Sample command for fun12",
    execute(client, message, args) {
        message.reply("fun12 command executed!");
    }
};