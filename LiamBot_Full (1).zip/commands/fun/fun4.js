module.exports = {
    name: "fun4",
    description: "Sample command for fun4",
    execute(client, message, args) {
        message.reply("fun4 command executed!");
    }
};