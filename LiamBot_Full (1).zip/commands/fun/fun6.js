module.exports = {
    name: "fun6",
    description: "Sample command for fun6",
    execute(client, message, args) {
        message.reply("fun6 command executed!");
    }
};