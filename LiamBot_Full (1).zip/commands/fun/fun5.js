module.exports = {
    name: "fun5",
    description: "Sample command for fun5",
    execute(client, message, args) {
        message.reply("fun5 command executed!");
    }
};