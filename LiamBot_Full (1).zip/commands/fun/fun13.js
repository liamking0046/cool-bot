module.exports = {
    name: "fun13",
    description: "Sample command for fun13",
    execute(client, message, args) {
        message.reply("fun13 command executed!");
    }
};