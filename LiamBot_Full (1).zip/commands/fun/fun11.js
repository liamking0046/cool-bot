module.exports = {
    name: "fun11",
    description: "Sample command for fun11",
    execute(client, message, args) {
        message.reply("fun11 command executed!");
    }
};