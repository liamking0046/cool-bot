module.exports = {
    name: "fun7",
    description: "Sample command for fun7",
    execute(client, message, args) {
        message.reply("fun7 command executed!");
    }
};