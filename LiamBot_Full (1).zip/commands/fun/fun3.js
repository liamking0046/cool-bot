module.exports = {
    name: "fun3",
    description: "Sample command for fun3",
    execute(client, message, args) {
        message.reply("fun3 command executed!");
    }
};