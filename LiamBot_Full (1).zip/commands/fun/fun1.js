module.exports = {
    name: "fun1",
    description: "Sample command for fun1",
    execute(client, message, args) {
        message.reply("fun1 command executed!");
    }
};