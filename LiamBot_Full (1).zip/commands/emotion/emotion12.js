module.exports = {
    name: "emotion12",
    description: "Sample command for emotion12",
    execute(client, message, args) {
        message.reply("emotion12 command executed!");
    }
};