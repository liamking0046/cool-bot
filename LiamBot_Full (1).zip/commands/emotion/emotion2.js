module.exports = {
    name: "emotion2",
    description: "Sample command for emotion2",
    execute(client, message, args) {
        message.reply("emotion2 command executed!");
    }
};