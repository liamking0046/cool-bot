module.exports = {
    name: "emotion7",
    description: "Sample command for emotion7",
    execute(client, message, args) {
        message.reply("emotion7 command executed!");
    }
};