module.exports = {
    name: "emotion11",
    description: "Sample command for emotion11",
    execute(client, message, args) {
        message.reply("emotion11 command executed!");
    }
};