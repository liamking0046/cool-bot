module.exports = {
    name: "emotion4",
    description: "Sample command for emotion4",
    execute(client, message, args) {
        message.reply("emotion4 command executed!");
    }
};