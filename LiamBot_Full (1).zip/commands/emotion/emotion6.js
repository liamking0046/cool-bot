module.exports = {
    name: "emotion6",
    description: "Sample command for emotion6",
    execute(client, message, args) {
        message.reply("emotion6 command executed!");
    }
};