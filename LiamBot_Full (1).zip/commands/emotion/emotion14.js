module.exports = {
    name: "emotion14",
    description: "Sample command for emotion14",
    execute(client, message, args) {
        message.reply("emotion14 command executed!");
    }
};