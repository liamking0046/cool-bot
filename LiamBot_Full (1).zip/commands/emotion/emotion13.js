module.exports = {
    name: "emotion13",
    description: "Sample command for emotion13",
    execute(client, message, args) {
        message.reply("emotion13 command executed!");
    }
};