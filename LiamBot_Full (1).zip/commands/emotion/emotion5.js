module.exports = {
    name: "emotion5",
    description: "Sample command for emotion5",
    execute(client, message, args) {
        message.reply("emotion5 command executed!");
    }
};