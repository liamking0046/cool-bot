module.exports = {
    name: "emotion3",
    description: "Sample command for emotion3",
    execute(client, message, args) {
        message.reply("emotion3 command executed!");
    }
};