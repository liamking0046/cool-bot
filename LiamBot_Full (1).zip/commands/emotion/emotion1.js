module.exports = {
    name: "emotion1",
    description: "Sample command for emotion1",
    execute(client, message, args) {
        message.reply("emotion1 command executed!");
    }
};