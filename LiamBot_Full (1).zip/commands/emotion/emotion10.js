module.exports = {
    name: "emotion10",
    description: "Sample command for emotion10",
    execute(client, message, args) {
        message.reply("emotion10 command executed!");
    }
};