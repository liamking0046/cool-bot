module.exports = {
    name: "emotion8",
    description: "Sample command for emotion8",
    execute(client, message, args) {
        message.reply("emotion8 command executed!");
    }
};