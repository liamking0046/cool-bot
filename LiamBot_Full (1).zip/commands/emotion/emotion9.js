module.exports = {
    name: "emotion9",
    description: "Sample command for emotion9",
    execute(client, message, args) {
        message.reply("emotion9 command executed!");
    }
};