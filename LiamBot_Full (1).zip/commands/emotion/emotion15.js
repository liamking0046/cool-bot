module.exports = {
    name: "emotion15",
    description: "Sample command for emotion15",
    execute(client, message, args) {
        message.reply("emotion15 command executed!");
    }
};