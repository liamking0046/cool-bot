module.exports = {
    name: "media13",
    description: "Sample command for media13",
    execute(client, message, args) {
        message.reply("media13 command executed!");
    }
};