module.exports = {
    name: "media7",
    description: "Sample command for media7",
    execute(client, message, args) {
        message.reply("media7 command executed!");
    }
};