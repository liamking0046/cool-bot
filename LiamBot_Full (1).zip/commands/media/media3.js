module.exports = {
    name: "media3",
    description: "Sample command for media3",
    execute(client, message, args) {
        message.reply("media3 command executed!");
    }
};