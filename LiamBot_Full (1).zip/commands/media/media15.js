module.exports = {
    name: "media15",
    description: "Sample command for media15",
    execute(client, message, args) {
        message.reply("media15 command executed!");
    }
};