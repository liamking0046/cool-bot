module.exports = {
    name: "media12",
    description: "Sample command for media12",
    execute(client, message, args) {
        message.reply("media12 command executed!");
    }
};