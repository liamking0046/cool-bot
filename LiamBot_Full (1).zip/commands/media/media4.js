module.exports = {
    name: "media4",
    description: "Sample command for media4",
    execute(client, message, args) {
        message.reply("media4 command executed!");
    }
};