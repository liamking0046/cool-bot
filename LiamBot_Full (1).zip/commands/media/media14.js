module.exports = {
    name: "media14",
    description: "Sample command for media14",
    execute(client, message, args) {
        message.reply("media14 command executed!");
    }
};