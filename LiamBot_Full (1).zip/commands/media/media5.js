module.exports = {
    name: "media5",
    description: "Sample command for media5",
    execute(client, message, args) {
        message.reply("media5 command executed!");
    }
};