module.exports = {
    name: "media6",
    description: "Sample command for media6",
    execute(client, message, args) {
        message.reply("media6 command executed!");
    }
};