module.exports = {
    name: "media8",
    description: "Sample command for media8",
    execute(client, message, args) {
        message.reply("media8 command executed!");
    }
};