module.exports = {
    name: "media9",
    description: "Sample command for media9",
    execute(client, message, args) {
        message.reply("media9 command executed!");
    }
};