module.exports = {
    name: "media1",
    description: "Sample command for media1",
    execute(client, message, args) {
        message.reply("media1 command executed!");
    }
};