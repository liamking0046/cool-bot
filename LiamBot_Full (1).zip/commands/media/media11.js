module.exports = {
    name: "media11",
    description: "Sample command for media11",
    execute(client, message, args) {
        message.reply("media11 command executed!");
    }
};