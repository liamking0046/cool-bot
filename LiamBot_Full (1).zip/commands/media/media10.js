module.exports = {
    name: "media10",
    description: "Sample command for media10",
    execute(client, message, args) {
        message.reply("media10 command executed!");
    }
};