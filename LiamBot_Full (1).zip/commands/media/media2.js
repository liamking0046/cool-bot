module.exports = {
    name: "media2",
    description: "Sample command for media2",
    execute(client, message, args) {
        message.reply("media2 command executed!");
    }
};