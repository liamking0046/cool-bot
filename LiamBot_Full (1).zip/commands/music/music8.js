module.exports = {
    name: "music8",
    description: "Sample command for music8",
    execute(client, message, args) {
        message.reply("music8 command executed!");
    }
};