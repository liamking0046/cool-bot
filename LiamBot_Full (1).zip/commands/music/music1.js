module.exports = {
    name: "music1",
    description: "Sample command for music1",
    execute(client, message, args) {
        message.reply("music1 command executed!");
    }
};