module.exports = {
    name: "music10",
    description: "Sample command for music10",
    execute(client, message, args) {
        message.reply("music10 command executed!");
    }
};