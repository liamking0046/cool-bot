module.exports = {
    name: "music3",
    description: "Sample command for music3",
    execute(client, message, args) {
        message.reply("music3 command executed!");
    }
};