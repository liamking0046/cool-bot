module.exports = {
    name: "music12",
    description: "Sample command for music12",
    execute(client, message, args) {
        message.reply("music12 command executed!");
    }
};