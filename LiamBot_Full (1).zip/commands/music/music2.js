module.exports = {
    name: "music2",
    description: "Sample command for music2",
    execute(client, message, args) {
        message.reply("music2 command executed!");
    }
};