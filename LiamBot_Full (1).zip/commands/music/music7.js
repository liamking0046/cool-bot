module.exports = {
    name: "music7",
    description: "Sample command for music7",
    execute(client, message, args) {
        message.reply("music7 command executed!");
    }
};