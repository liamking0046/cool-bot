module.exports = {
    name: "music15",
    description: "Sample command for music15",
    execute(client, message, args) {
        message.reply("music15 command executed!");
    }
};