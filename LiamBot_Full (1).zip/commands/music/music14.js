module.exports = {
    name: "music14",
    description: "Sample command for music14",
    execute(client, message, args) {
        message.reply("music14 command executed!");
    }
};