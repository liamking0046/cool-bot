module.exports = {
    name: "music5",
    description: "Sample command for music5",
    execute(client, message, args) {
        message.reply("music5 command executed!");
    }
};