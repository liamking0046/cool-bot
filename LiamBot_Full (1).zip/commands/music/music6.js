module.exports = {
    name: "music6",
    description: "Sample command for music6",
    execute(client, message, args) {
        message.reply("music6 command executed!");
    }
};