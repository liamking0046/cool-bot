module.exports = {
    name: "music4",
    description: "Sample command for music4",
    execute(client, message, args) {
        message.reply("music4 command executed!");
    }
};