module.exports = {
    name: "music13",
    description: "Sample command for music13",
    execute(client, message, args) {
        message.reply("music13 command executed!");
    }
};