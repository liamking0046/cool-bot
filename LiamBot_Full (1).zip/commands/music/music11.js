module.exports = {
    name: "music11",
    description: "Sample command for music11",
    execute(client, message, args) {
        message.reply("music11 command executed!");
    }
};