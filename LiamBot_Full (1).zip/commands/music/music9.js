module.exports = {
    name: "music9",
    description: "Sample command for music9",
    execute(client, message, args) {
        message.reply("music9 command executed!");
    }
};