module.exports = {
    name: "shop",
    description: "Sample command for shop",
    execute(client, message, args) {
        message.reply("shop command executed!");
    }
};