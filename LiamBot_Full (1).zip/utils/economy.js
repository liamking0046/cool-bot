module.exports = {
    name: "economy",
    description: "Sample command for economy",
    execute(client, message, args) {
        message.reply("economy command executed!");
    }
};